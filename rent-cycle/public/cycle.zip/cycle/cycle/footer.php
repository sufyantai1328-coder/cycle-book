</div>
<footer class="footer">
  <div class="container">
    &copy; <?php echo date('Y'); ?> Cycle Booking. All rights reserved.
  </div>
</footer>
</body>
</html>