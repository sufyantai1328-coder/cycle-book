<?php
require '../db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass = $_POST['password'];
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO admins (name,email,password) VALUES (?,?,?)");
    $stmt->bind_param('sss', $name, $email, $hash);
    if ($stmt->execute()) {
        header('Location: admin_login.php');
        exit;
    } else {
        $error = 'Cannot create admin (email may exist).';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Register Admin</title></head><body>
<div style="max-width:400px;margin:30px auto">
  <h2>Create Admin Account</h2>
  <?php if (!empty($error)) echo '<p style="color:red">'.$error.'</p>'; ?>
  <form method="post">
    <label>Name</label><br><input name="name" required><br>
    <label>Email</label><br><input name="email" type="email" required><br>
    <label>Password</label><br><input name="password" type="password" required><br><br>
    <button type="submit">Register Admin</button>
  </form>
  <p>Go to <a href="admin_login.php">Admin Login</a></p>
</div></body></html>
