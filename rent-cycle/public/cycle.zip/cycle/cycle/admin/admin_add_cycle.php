<?php
require '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) header('Location: admin_login.php');

// fetch suppliers for dropdown
$sres = $conn->query("SELECT id,name FROM suppliers ORDER BY name");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplier_id = !empty($_POST['supplier_id']) ? intval($_POST['supplier_id']) : NULL;
    $name = $_POST['name']; $desc = $_POST['description']; $price = floatval($_POST['price']); $qty = intval($_POST['qty']);
    $imgpath = 'images/default.png';
    if (!empty($_FILES['image']['name'])) {
        $uploaddir = '../images/';
        if (!is_dir($uploaddir)) mkdir($uploaddir, 0755, true);
        $filename = time().'_'.basename($_FILES['image']['name']);
        $target = $uploaddir.$filename;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $imgpath = 'images/'.$filename;
        }
    }
    $stmt = $conn->prepare("INSERT INTO cycles (supplier_id,name,description,price,qty,image) VALUES (?,?,?,?,?,?)");
    $stmt->bind_param('issdis', $supplier_id, $name, $desc, $price, $qty, $imgpath);
    $stmt->execute();
    header('Location: admin_cycles.php');
    exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Add Cycle</title></head><body>
<div style="max-width:600px;margin:20px auto">
  <h2>Add Cycle</h2>
  <form method="post" enctype="multipart/form-data">
    <div class="form-row"><label>Supplier</label><br>
      <select name="supplier_id">
        <option value="">-- None --</option>
        <?php while($s = $sres->fetch_assoc()): ?>
          <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="form-row"><label>Name</label><br><input name="name" required></div>
    <div class="form-row"><label>Description</label><br><textarea name="description"></textarea></div>
    <div class="form-row"><label>Price</label><br><input name="price" type="number" step="0.01" required></div>
    <div class="form-row"><label>Qty</label><br><input name="qty" type="number" required value="1"></div>
    <div class="form-row"><label>Image</label><br><input name="image" type="file" accept="image/*"></div>
    <div class="form-row"><button type="submit">Save</button></div>
  </form>
  <p><a href="admin_cycles.php">Back to cycles</a></p>
</div></body></html>
