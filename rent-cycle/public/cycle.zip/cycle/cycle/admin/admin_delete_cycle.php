<?php
require '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) header('Location: admin_login.php');
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id) {
    $conn->query("DELETE FROM cycles WHERE id = ".intval($id));
}
header('Location: admin/admin_cycles.php');
exit;
?>