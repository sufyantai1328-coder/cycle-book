<?php
require '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) header('Location: admin_login.php');
$res = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
?>
<!doctype html><html><head><meta charset="utf-8"><title>Users</title></head><body>
<div style="max-width:900px;margin:20px auto">
  <h2>Registered Users</h2>
  <p><a href="admin_dashboard.php">Dashboard</a> | <a href="admin_logout.php">Logout</a></p>
  <table class="table">
    <tr><th>ID</th><th>Name</th><th>Email</th><th>Joined</th></tr>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo $r['id']; ?></td>
        <td><?php echo htmlspecialchars($r['name']); ?></td>
        <td><?php echo htmlspecialchars($r['email']); ?></td>
        <td><?php echo $r['created_at']; ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div></body></html>
