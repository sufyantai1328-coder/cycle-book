<?php
require '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) header('Location: admin_login.php');
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $conn->prepare("SELECT o.*, u.name as user_name, u.email as user_email FROM orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.id = ?");
$stmt->bind_param('i',$id); $stmt->execute(); $res = $stmt->get_result(); $order = $res->fetch_assoc();
if (!$order) { echo 'Order not found'; exit; }
$itres = $conn->query("SELECT oi.*, c.name as cycle_name FROM order_items oi LEFT JOIN cycles c ON c.id = oi.cycle_id WHERE oi.order_id = $id");
?>
<!doctype html><html><head><meta charset="utf-8"><title>Order Details</title></head><body>
<div style="max-width:800px;margin:20px auto">
  <h2>Order #<?php echo $order['id']; ?></h2>
  <p>User: <?php echo htmlspecialchars($order['user_name']) . ' (' . htmlspecialchars($order['user_email']) . ')'; ?></p>
  <p>Total: ₹<?php echo number_format($order['total'],2); ?></p>
  <p>Status: <?php echo htmlspecialchars($order['status']); ?></p>
  <h3>Items</h3>
  <table class="table">
    <tr><th>Cycle</th><th>Qty</th><th>Price</th></tr>
    <?php while($it = $itres->fetch_assoc()): ?>
      <tr>
        <td><?php echo htmlspecialchars($it['cycle_name']); ?></td>
        <td><?php echo intval($it['qty']); ?></td>
        <td>₹<?php echo number_format($it['price'],2); ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
  <p><a href="admin_orders.php">Back to orders</a></p>
</div></body></html>
