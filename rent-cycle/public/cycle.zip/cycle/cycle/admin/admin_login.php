<?php
session_start();
include '../db.php'; // make sure this points to your database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // check if admin exists in users table
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin' LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // verify password
        if (password_verify($password, $user['password'])) {
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_name'] = $user['name'];
            header("Location: dashboard.php"); // redirect to admin dashboard
            exit;
        } else {
            echo "❌ Invalid password";
        }
    } else {
        echo "❌ No admin found with that email";
    }

    $stmt->close();
}
?>
