<?php
require '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) header('Location: admin_login.php');

$res1 = $conn->query("SELECT COUNT(*) as c FROM cycles"); $cycles = $res1->fetch_assoc()['c'];
$res2 = $conn->query("SELECT COUNT(*) as c FROM users"); $users = $res2->fetch_assoc()['c'];
$res3 = $conn->query("SELECT COUNT(*) as c FROM orders"); $orders = $res3->fetch_assoc()['c'];
$res4 = $conn->query("SELECT COUNT(*) as c FROM suppliers"); $suppliers = $res4->fetch_assoc()['c'];
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Dashboard</title></head><body>
<div style="max-width:900px;margin:20px auto">
  <h2>Admin Dashboard</h2>
  <p>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?> | <a href="admin_logout.php">Logout</a></p>
  <div style="display:flex;gap:10px">
    <div style="flex:1;background:#fff;padding:10px"><h3>Cycles</h3><p><?php echo $cycles; ?></p></div>
    <div style="flex:1;background:#fff;padding:10px"><h3>Users</h3><p><?php echo $users; ?></p></div>
    <div style="flex:1;background:#fff;padding:10px"><h3>Orders</h3><p><?php echo $orders; ?></p></div>
    <div style="flex:1;background:#fff;padding:10px"><h3>Suppliers</h3><p><?php echo $suppliers; ?></p></div>
  </div>
  <p><a href="admin/admin_cycles.php">Manage Cycles</a> | <a href="admin/admin_orders.php">View Orders</a> | <a href="admin/admin_users.php">View Users</a> | <a href="admin/admin_suppliers.php">Suppliers</a></p>
</div></body></html>
