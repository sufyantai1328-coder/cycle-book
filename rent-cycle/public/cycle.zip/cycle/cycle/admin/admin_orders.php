<?php
require '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) header('Location: admin_login.php');

$res = $conn->query("SELECT o.*, u.name as user_name, u.email as user_email FROM orders o LEFT JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC");
?>
<!doctype html><html><head><meta charset="utf-8"><title>Orders</title></head><body>
<div style="max-width:1000px;margin:20px auto">
  <h2>Orders</h2>
  <p><a href="admin_dashboard.php">Dashboard</a> | <a href="admin_logout.php">Logout</a></p>
  <table class="table">
    <tr><th>Order ID</th><th>User</th><th>Total</th><th>Status</th><th>Date</th><th>Details</th></tr>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo $r['id']; ?></td>
        <td><?php echo htmlspecialchars($r['user_name']) . ' (' . htmlspecialchars($r['user_email']) . ')'; ?></td>
        <td>₹<?php echo number_format($r['total'],2); ?></td>
        <td><?php echo htmlspecialchars($r['status']); ?></td>
        <td><?php echo $r['created_at']; ?></td>
        <td><a href="admin_order_details.php?id=<?php echo $r['id']; ?>">View</a></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div></body></html>
