<?php
require '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) header('Location: admin_login.php');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $conn->prepare("SELECT * FROM cycles WHERE id = ?");
$stmt->bind_param('i',$id);
$stmt->execute();
$res = $stmt->get_result();
$cycle = $res->fetch_assoc();
if (!$cycle) { echo 'Not found'; exit; }

$sres = $conn->query("SELECT id,name FROM suppliers ORDER BY name");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplier_id = !empty($_POST['supplier_id']) ? intval($_POST['supplier_id']) : NULL;
    $name = $_POST['name']; $desc = $_POST['description']; $price = floatval($_POST['price']); $qty = intval($_POST['qty']);
    $imgpath = $cycle['image'];
    if (!empty($_FILES['image']['name'])) {
        $uploaddir = '../images/';
        if (!is_dir($uploaddir)) mkdir($uploaddir, 0755, true);
        $filename = time().'_'.basename($_FILES['image']['name']);
        $target = $uploaddir.$filename;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $imgpath = 'images/'.$filename;
        }
    }
    $ust = $conn->prepare("UPDATE cycles SET supplier_id=?,name=?,description=?,price=?,qty=?,image=? WHERE id=?");
    $ust->bind_param('issdisi',$supplier_id,$name,$desc,$price,$qty,$imgpath,$id);
    $ust->execute();
    header('Location: admin_cycles.php');
    exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Edit Cycle</title></head><body>
<div style="max-width:600px;margin:20px auto">
  <h2>Edit Cycle</h2>
  <form method="post" enctype="multipart/form-data">
    <div class="form-row"><label>Supplier</label><br>
      <select name="supplier_id">
        <option value="">-- None --</option>
        <?php while($s = $sres->fetch_assoc()): ?>
          <option value="<?php echo $s['id']; ?>" <?php if($cycle['supplier_id']==$s['id']) echo 'selected'; ?>><?php echo htmlspecialchars($s['name']); ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="form-row"><label>Name</label><br><input name="name" required value="<?php echo htmlspecialchars($cycle['name']); ?>"></div>
    <div class="form-row"><label>Description</label><br><textarea name="description"><?php echo htmlspecialchars($cycle['description']); ?></textarea></div>
    <div class="form-row"><label>Price</label><br><input name="price" type="number" step="0.01" required value="<?php echo htmlspecialchars($cycle['price']); ?>"></div>
    <div class="form-row"><label>Qty</label><br><input name="qty" type="number" required value="<?php echo htmlspecialchars($cycle['qty']); ?>"></div>
    <div class="form-row"><label>Image (leave blank to keep)</label><br><input name="image" type="file" accept="image/*"><br><img src="../<?php echo htmlspecialchars($cycle['image']); ?>" style="height:80px;margin-top:10px"></div>
    <div class="form-row"><button type="submit">Update</button></div>
  </form>
  <p><a href="admin_cycles.php">Back to cycles</a></p>
</div></body></html>
