<?php
require '../db.php';
session_start();
if (!isset($_SESSION['admin_id'])) header('Location: admin_login.php');
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = trim($_POST['name']); $email = trim($_POST['email']); $pass = $_POST['password'];
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO suppliers (name,email,password) VALUES (?,?,?)");
    $stmt->bind_param('sss',$name,$email,$hash);
    $stmt->execute();
    header('Location: admin_suppliers.php');
    exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Add Supplier</title></head><body>
<div style="max-width:400px;margin:30px auto">
  <h2>Add Supplier</h2>
  <form method="post">
    <label>Name</label><br><input name="name" required><br>
    <label>Email</label><br><input name="email" type="email" required><br>
    <label>Password</label><br><input name="password" type="password" required><br><br>
    <button type="submit">Add Supplier</button>
  </form>
  <p><a href="admin_suppliers.php">Back</a></p>
</div></body></html>
