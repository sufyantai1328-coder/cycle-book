<?php
session_start();
require '../db.php';

// check login
if (!isset($_SESSION['supplier_id'])) {
    header("Location: supplier_login.php");
    exit;
}

$supplier_id = $_SESSION['supplier_id'];

// fetch cycles for this supplier
$stmt = $conn->prepare("SELECT * FROM cycles WHERE supplier_id = ?");
$stmt->bind_param("i", $supplier_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>My Cycles</title>
  <style>
    body { font-family: Arial, sans-serif; background:#f4f4f9; }
    .container { max-width:800px; margin:40px auto; background:#fff; padding:20px;
                 border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,0.2); }
    h2 { text-align:center; }
    table { width:100%; border-collapse: collapse; margin-top:20px; }
    th, td { border:1px solid #ddd; padding:10px; text-align:center; }
    th { background:#007bff; color:white; }
    a.btn {
      display:inline-block; padding:5px 10px; border-radius:5px;
      text-decoration:none; color:white; font-size:14px;
    }
    .edit { background:#28a745; }
    .delete { background:#dc3545; }
    .back { display:block; margin-top:20px; text-align:center; }
  </style>
</head>
<body>
  <div class="container">
    <h2>📋 My Cycles</h2>
    <table>
      <tr>
        <th>ID</th>
        <th>Cycle Name</th>
        <th>Description</th>
        <th>Price (₹)</th>
        <th>Stock</th>
        <th>Actions</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['cycle_name']) ?></td>
        <td><?= htmlspecialchars($row['description']) ?></td>
        <td><?= $row['price'] ?></td>
        <td><?= $row['available_stock'] ?></td>
        <td>
          <a class="btn edit" href="supplier_edit_cycle.php?id=<?= $row['id'] ?>">Edit</a>
          <a class="btn delete" href="supplier_delete_cycle.php?id=<?= $row['id'] ?>"
             onclick="return confirm('Are you sure you want to delete this cycle?');">Delete</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>

    <div class="back">
      <a href="supplier_dashboard.php">⬅ Back to Dashboard</a>
    </div>
  </div>
</body>
</html>
