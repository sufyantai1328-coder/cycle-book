<p style="text-align:center; margin-top:20px;">
  <a href="supplier_add_cycle.php">➕ Add New Cycle</a>
</p>
<p style="text-align:center;">
  <a href="supplier_view_cycle.php">📋 View My Cycles</a>
</p>
