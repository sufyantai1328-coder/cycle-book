<?php
require '../db.php';
session_start();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email = trim($_POST['email']); $pass = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM suppliers WHERE email = ?");
    $stmt->bind_param('s',$email); $stmt->execute(); $res = $stmt->get_result(); $s = $res->fetch_assoc();
    if ($s && password_verify($pass, $s['password'])) {
        $_SESSION['supplier_id'] = $s['id']; $_SESSION['supplier_name'] = $s['name'];
        header('Location: supplier_dashboard.php'); exit;
    } else $error='Invalid credentials';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Supplier Login</title></head><body>
<div style="max-width:400px;margin:30px auto">
  <h2>Supplier Login</h2>
  <?php if (!empty($error)) echo '<p style="color:red">'.$error.'</p>'; ?>
  <form method="post">
    <label>Email</label><br><input name="email" type="email" required><br>
    <label>Password</label><br><input name="password" type="password" required><br><br>
    <button type="submit">Login</button>
  </form>
  <p>Register as supplier <a href="supplier_register.php">here</a></p>
</div></body></html>
