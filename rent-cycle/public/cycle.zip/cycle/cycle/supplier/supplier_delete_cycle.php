<?php
session_start();
require '../db.php';

if (!isset($_SESSION['supplier_id'])) {
    header("Location: supplier_login.php");
    exit;
}

$id = $_GET['id'] ?? null;
$supplier_id = $_SESSION['supplier_id'];

if ($id) {
    $stmt = $conn->prepare("DELETE FROM cycles WHERE id=? AND supplier_id=?");
    $stmt->bind_param("ii", $id, $supplier_id);
    $stmt->execute();
}

header("Location: supplier_view_cycles.php");
exit;
?>
