<?php
session_start();
require '../db.php';

// Check if supplier is logged in
if (!isset($_SESSION['supplier_id'])) {
    header("Location: supplier_login.php");
    exit;
}

$message = "";

// Handle form submit
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cycle_name = trim($_POST['cycle_name']);
    $description = trim($_POST['description']);
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $supplier_id = $_SESSION['supplier_id'];

    $stmt = $conn->prepare("INSERT INTO cycles (cycle_name, description, price, available_stock, supplier_id) 
                            VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdii", $cycle_name, $description, $price, $stock, $supplier_id);

    if ($stmt->execute()) {
        $message = "✅ Cycle added successfully!";
    } else {
        $message = "❌ Error: " . $stmt->error;
    }
    $stmt->close();
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add Cycle - Supplier</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f4f9; }
    .container { max-width: 600px; margin: 50px auto; background: #fff; padding: 20px;
                 border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
    h2 { text-align: center; }
    label { display: block; margin-top: 10px; }
    input, textarea {
      width: 100%; padding: 8px; margin-top: 5px;
      border: 1px solid #ccc; border-radius: 5px;
    }
    button {
      margin-top: 15px; padding: 10px 15px; border: none; border-radius: 5px;
      background: #28a745; color: white; cursor: pointer;
    }
    button:hover { background: #218838; }
    .msg { text-align:center; margin:10px 0; color: green; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Add New Cycle</h2>
    <?php if (!empty($message)) echo "<p class='msg'>$message</p>"; ?>
    <form method="post">
      <label>Cycle Name</label>
      <input type="text" name="cycle_name" required>

      <label>Description</label>
      <textarea name="description" rows="3"></textarea>

      <label>Price (₹)</label>
      <input type="number" step="0.01" name="price" required>

      <label>Available Stock</label>
      <input type="number" name="stock" required>

      <button type="submit">Add Cycle</button>
    </form>
    <p style="text-align:center; margin-top:15px;">
      <a href="supplier_dashboard.php">⬅ Back to Dashboard</a>
    </p>
  </div>
</body>
</html>
