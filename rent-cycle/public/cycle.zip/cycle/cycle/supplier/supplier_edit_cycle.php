<?php
session_start();
require '../db.php';

if (!isset($_SESSION['supplier_id'])) {
    header("Location: supplier_login.php");
    exit;
}

$id = $_GET['id'] ?? null;
$supplier_id = $_SESSION['supplier_id'];

if (!$id) {
    die("Invalid cycle ID");
}

// fetch cycle
$stmt = $conn->prepare("SELECT * FROM cycles WHERE id=? AND supplier_id=?");
$stmt->bind_param("ii", $id, $supplier_id);
$stmt->execute();
$cycle = $stmt->get_result()->fetch_assoc();

if (!$cycle) {
    die("Cycle not found");
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cycle_name = $_POST['cycle_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    $stmt = $conn->prepare("UPDATE cycles SET cycle_name=?, description=?, price=?, available_stock=? WHERE id=? AND supplier_id=?");
    $stmt->bind_param("ssdiii", $cycle_name, $description, $price, $stock, $id, $supplier_id);

    if ($stmt->execute()) {
        $message = "✅ Cycle updated successfully!";
        // refresh cycle data
        $stmt = $conn->prepare("SELECT * FROM cycles WHERE id=? AND supplier_id=?");
        $stmt->bind_param("ii", $id, $supplier_id);
        $stmt->execute();
        $cycle = $stmt->get_result()->fetch_assoc();
    } else {
        $message = "❌ Error: " . $stmt->error;
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Edit Cycle</title></head>
<body style="font-family:Arial;background:#f4f4f9">
<div style="max-width:500px;margin:40px auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 2px 5px rgba(0,0,0,.2)">
  <h2>Edit Cycle</h2>
  <?php if ($message) echo "<p style='color:green'>$message</p>"; ?>
  <form method="post">
    <label>Name</label><br>
    <input type="text" name="cycle_name" value="<?= htmlspecialchars($cycle['cycle_name']) ?>" required><br>
    <label>Description</label><br>
    <textarea name="description"><?= htmlspecialchars($cycle['description']) ?></textarea><br>
    <label>Price</label><br>
    <input type="number" step="0.01" name="price" value="<?= $cycle['price'] ?>" required><br>
    <label>Stock</label><br>
    <input type="number" name="stock" value="<?= $cycle['available_stock'] ?>" required><br><br>
    <button type="submit">Update</button>
  </form>
  <p><a href="supplier_view_cycles.php">⬅ Back</a></p>
</div>
</body>
</html>
