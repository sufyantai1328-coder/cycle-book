<?php
require '../db.php';
session_start();
if (!isset($_SESSION['supplier_id'])) header('Location: supplier_login.php');
$sid = $_SESSION['supplier_id'];
$res = $conn->query("SELECT DISTINCT o.* FROM orders o JOIN order_items oi ON oi.order_id=o.id JOIN cycles c ON c.id=oi.cycle_id WHERE c.supplier_id = $sid ORDER BY o.created_at DESC");
?>
<!doctype html><html><head><meta charset="utf-8"><title>Orders for My Cycles</title></head><body>
<div style="max-width:1000px;margin:20px auto">
  <h2>Orders for My Cycles</h2>
  <p><a href="supplier_dashboard.php">Dashboard</a> | <a href="supplier_logout.php">Logout</a></p>
  <table class="table">
    <tr><th>Order ID</th><th>User</th><th>Total</th><th>Status</th><th>Date</th><th>Details</th></tr>
    <?php while($r = $res->fetch_assoc()): 
      $uid = $r['user_id']; $u = $conn->query("SELECT name,email FROM users WHERE id=$uid")->fetch_assoc();
    ?>
      <tr>
        <td><?php echo $r['id']; ?></td>
        <td><?php echo htmlspecialchars($u['name']) . ' (' . htmlspecialchars($u['email']) . ')'; ?></td>
        <td>₹<?php echo number_format($r['total'],2); ?></td>
        <td><?php echo htmlspecialchars($r['status']); ?></td>
        <td><?php echo $r['created_at']; ?></td>
        <td><a href="supplier_order_details.php?id=<?php echo $r['id']; ?>">View</a></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div></body></html>
