<?php
require '../db.php';
session_start();
if (!isset($_SESSION['supplier_id'])) header('Location: supplier_login.php');
$sid = $_SESSION['supplier_id'];
$res = $conn->query("SELECT * FROM cycles WHERE supplier_id = $sid ORDER BY created_at DESC");
?>
<!doctype html><html><head><meta charset="utf-8"><title>My Cycles</title></head><body>
<div style="max-width:1000px;margin:20px auto">
  <h2>My Cycles</h2>
  <p><a href="supplier_dashboard.php">Dashboard</a> | <a href="supplier_add_cycle.php">Add Cycle</a> | <a href="supplier_logout.php">Logout</a></p>
  <table class="table">
    <tr><th>ID</th><th>Name</th><th>Price</th><th>Qty</th><th>Image</th><th>Actions</th></tr>
    <?php while($r = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo $r['id']; ?></td>
        <td><?php echo htmlspecialchars($r['name']); ?></td>
        <td>₹<?php echo number_format($r['price'],2); ?></td>
        <td><?php echo intval($r['qty']); ?></td>
        <td><img src="../<?php echo htmlspecialchars($r['image']); ?>" style="height:40px"></td>
        <td><a href="supplier_edit_cycle.php?id=<?php echo $r['id']; ?>">Edit</a> | <a href="supplier_delete_cycle.php?id=<?php echo $r['id']; ?>" onclick="return confirm('Delete?')">Delete</a></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div></body></html>
