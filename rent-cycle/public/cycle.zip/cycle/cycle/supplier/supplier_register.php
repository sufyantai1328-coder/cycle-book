<?php
require '../db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];
    $company = trim($_POST['company']);

    // Hash the password
    $hashedPass = password_hash($pass, PASSWORD_BCRYPT);

    // Insert into suppliers table
    $stmt = $conn->prepare("INSERT INTO suppliers (name, email, password, company) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $hashedPass, $company);

    if ($stmt->execute()) {
        $_SESSION['supplier_id'] = $stmt->insert_id;
        $_SESSION['supplier_name'] = $name;
        header("Location: supplier_dashboard.php");
        exit;
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Supplier Registration</title>
</head>
<body>
<div style="max-width:400px;margin:30px auto">
  <h2>Register as Supplier</h2>
  <?php if (!empty($error)) echo '<p style="color:red">'.$error.'</p>'; ?>
  <form method="post">
    <label>Name</label><br>
    <input name="name" required><br>

    <label>Email</label><br>
    <input type="email" name="email" required><br>

    <label>Password</label><br>
    <input type="password" name="password" required><br>

    <label>Company</label><br>
    <input name="company"><br><br>

    <button type="submit">Register</button>
  </form>
  <p>Already registered? <a href="supplier_login.php">Login here</a></p>
</div>
</body>
</html>
